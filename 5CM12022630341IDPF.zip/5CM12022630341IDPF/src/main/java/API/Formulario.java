package API;

import java.io.BufferedReader;
import org.json.JSONObject;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Formulario extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

        // Leer el cuerpo de la solicitud
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader bufferedReader = request.getReader()) {
            char[] charBuffer = new char[128];
            int bytesRead;
            while ((bytesRead = bufferedReader.read(charBuffer)) != -1) {
                stringBuilder.append(charBuffer, 0, bytesRead);
            }
        } catch (IOException ex) {
            throw ex;
        }

        // Convertir el cuerpo de la solicitud a un objeto JSON
        String body = stringBuilder.toString();
        JSONObject jsonObj = new JSONObject(body);

        // Acceder a los datos enviados desde el formulario
        String id = jsonObj.getString("id");
        String pregunta = jsonObj.getString("pregunta");
        String respuesta = jsonObj.getString("respuesta");
        String drags = jsonObj.getString("drags");
        String targets = jsonObj.getString("targets");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection db = DriverManager.getConnection("jdbc:mysql://localhost/chat_db", "root", "1234");
            String sql = "INSERT INTO tablajson (columnajson) VALUES (?)";
            PreparedStatement ps = db.prepareStatement(sql);
            String json = String.format("{\"id\":\"%s\",\"pregunta\":\"%s\",\"respuesta\":\"%s\",\"drags\":%s,\"targets\":%s}", id, pregunta, respuesta, drags, targets);
            ps.setString(1, json);
            ps.executeUpdate();
            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write("{\"status\":\"success\"}");
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"status\":\"error\",\"message\":\"" + e.getMessage() + "\"}");
        }
    }
}
