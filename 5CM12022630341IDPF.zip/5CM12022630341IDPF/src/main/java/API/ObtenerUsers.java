package API;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

public class ObtenerUsers extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        String url = "jdbc:mysql://localhost/chat_db";
        String user = "root";
        String password = "1234";

        String query = "SELECT id, username FROM users";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            JSONArray usersArray = new JSONArray();

            while (rs.next()) {
                JSONObject userObj = new JSONObject();
                userObj.put("id", rs.getInt("id"));
                userObj.put("username", rs.getString("username"));
                usersArray.put(userObj);
            }

            out.print(usersArray.toString());
        } catch (Exception e) {
            e.printStackTrace();
            out.print("[]");
        }
    }
}
