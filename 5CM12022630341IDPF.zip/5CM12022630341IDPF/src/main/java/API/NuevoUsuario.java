package API;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class NuevoUsuario extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.addHeader("Access-Control-Allow-Origin", "*");

        // Parse JSON request
        Gson gson = new Gson();
        JsonObject jsonRequest = gson.fromJson(request.getReader(), JsonObject.class);
        String username = jsonRequest.get("username").getAsString();
        String password = jsonRequest.get("password").getAsString();

        System.out.println("Username: " + username);
        System.out.println("Password: " + password);

        try (PrintWriter out = response.getWriter()) {
            registerUser(username, password);  // Note: Directly using the password, not hashed
            response.setStatus(HttpServletResponse.SC_OK);
            JsonObject jsonResponse = new JsonObject();
            jsonResponse.addProperty("message", "User registered successfully.");
            out.write(gson.toJson(jsonResponse));
        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            JsonObject jsonResponse = new JsonObject();
            jsonResponse.addProperty("error", "Error registering user: " + e.getMessage());
            response.getWriter().write(gson.toJson(jsonResponse));
        }
    }

    private void registerUser(String username, String password) throws SQLException {
        String url = "jdbc:mysql://localhost/chat_db";
        String user = "root";
        String passwordDB = "1234";

        String sql = "INSERT INTO users (username, password) VALUES (?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, passwordDB);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);
            int rowsAffected = ps.executeUpdate();
            System.out.println("Rows affected: " + rowsAffected);
        }
    }
}
