package API;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Eliminar extends HttpServlet {

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();

        int user1Id = Integer.parseInt(request.getParameter("user1Id"));
        int user2Id = Integer.parseInt(request.getParameter("user2Id"));

        String url = "jdbc:mysql://localhost/chat_db";
        String user = "root";
        String password = "1234";

        Connection conn = null;
        PreparedStatement psMessages = null;
        PreparedStatement psFiles = null;
        PreparedStatement psDeleteFiles = null;

        String sqlMessages = "DELETE FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)";
        String sqlFiles = "SELECT file_path FROM files WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)";
        String sqlDeleteFiles = "DELETE FROM files WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)";

        try {
            conn = DriverManager.getConnection(url, user, password);

            // Retrieve file paths to delete the files from the server
            psFiles = conn.prepareStatement(sqlFiles);
            psFiles.setInt(1, user1Id);
            psFiles.setInt(2, user2Id);
            psFiles.setInt(3, user2Id);
            psFiles.setInt(4, user1Id);
            ResultSet rsFiles = psFiles.executeQuery();
            while (rsFiles.next()) {
                String filePath = rsFiles.getString("file_path");
                File file = new File(filePath);
                if (file.exists()) {
                    file.delete();
                }
            }

            // Delete file metadata from the database
            psDeleteFiles = conn.prepareStatement(sqlDeleteFiles);
            psDeleteFiles.setInt(1, user1Id);
            psDeleteFiles.setInt(2, user2Id);
            psDeleteFiles.setInt(3, user2Id);
            psDeleteFiles.setInt(4, user1Id);
            psDeleteFiles.executeUpdate();

            // Delete text messages from the database
            psMessages = conn.prepareStatement(sqlMessages);
            psMessages.setInt(1, user1Id);
            psMessages.setInt(2, user2Id);
            psMessages.setInt(3, user2Id);
            psMessages.setInt(4, user1Id);
            int resultMessages = psMessages.executeUpdate();

            if (resultMessages > 0) {
                out.print("{\"status\":\"success\", \"message\":\"Chat eliminado exitosamente.\"}");
            } else {
                out.print("{\"status\":\"error\", \"message\":\"No se encontraron mensajes para eliminar.\"}");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            out.print("{\"status\":\"error\", \"message\":\"" + e.getMessage() + "\"}");
        } finally {
            try {
                if (psMessages != null) psMessages.close();
                if (psFiles != null) psFiles.close();
                if (psDeleteFiles != null) psDeleteFiles.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
