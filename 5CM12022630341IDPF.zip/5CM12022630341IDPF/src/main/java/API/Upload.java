package API;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import org.json.JSONObject;

@MultipartConfig
public class Upload extends HttpServlet {

    private static final String UPLOAD_DIR = "C:/tomcat90864/uploads";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");

        Part filePart = request.getPart("file");
        String fileName = filePart.getSubmittedFileName();
        String encodedFileName = URLEncoder.encode(fileName, "UTF-8").replace("+", "%20");
        String uploadPath = UPLOAD_DIR;
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdir();

        try (InputStream fileContent = filePart.getInputStream();
             FileOutputStream fos = new FileOutputStream(new File(uploadPath + File.separator + fileName))) {

            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fileContent.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
            }

            saveFileMetadata(request, fileName, uploadPath + "/" + encodedFileName);

            JSONObject jsonResponse = new JSONObject();
            jsonResponse.put("message", "File uploaded successfully.");
            jsonResponse.put("filePath", "/uploads/" + encodedFileName);
            response.getWriter().print(jsonResponse.toString());

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().print("{\"message\":\"File upload failed.\"}");
        }
    }

    private void saveFileMetadata(HttpServletRequest request, String fileName, String filePath) throws SQLException {
        int senderId = Integer.parseInt(request.getParameter("senderId"));
        int receiverId = Integer.parseInt(request.getParameter("receiverId"));

        String url = "jdbc:mysql://localhost/chat_db";
        String user = "root";
        String password = "1234";

        String sql = "INSERT INTO files (sender_id, receiver_id, file_name, file_path) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, senderId);
            ps.setInt(2, receiverId);
            ps.setString(3, fileName);
            ps.setString(4, filePath);
            ps.executeUpdate();
        }
    }
}
