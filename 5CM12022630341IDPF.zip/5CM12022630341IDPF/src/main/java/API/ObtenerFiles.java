package API;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

public class ObtenerFiles extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();

        int user1Id = Integer.parseInt(request.getParameter("user1Id"));
        int user2Id = Integer.parseInt(request.getParameter("user2Id"));

        String url = "jdbc:mysql://localhost/chat_db";
        String user = "root";
        String password = "1234";

        JSONArray jsonArray = new JSONArray();

        String sql = "SELECT id, sender_id, receiver_id, file_name, file_path, uploaded_at FROM files WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, user1Id);
            ps.setInt(2, user2Id);
            ps.setInt(3, user2Id);
            ps.setInt(4, user1Id);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("id", rs.getInt("id"));
                jsonObject.put("senderId", rs.getInt("sender_id"));
                jsonObject.put("receiverId", rs.getInt("receiver_id"));
                jsonObject.put("fileName", rs.getString("file_name"));
                jsonObject.put("filePath", "http://localhost:8080/uploads/" + rs.getString("file_name").replace(" ", "%20"));
                jsonObject.put("timestamp", rs.getString("uploaded_at"));
                jsonArray.put(jsonObject);
            }

            out.print(jsonArray.toString());
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"status\":\"error\", \"message\":\"" + e.getMessage() + "\"}");
        }
    }
}
