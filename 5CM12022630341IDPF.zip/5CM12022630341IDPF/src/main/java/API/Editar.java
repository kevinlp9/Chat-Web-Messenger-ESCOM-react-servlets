package API;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

public class Editar extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();

        Gson gson = new Gson();
        JsonObject jsonRequest = gson.fromJson(request.getReader(), JsonObject.class);
        int messageId = jsonRequest.get("id").getAsInt();
        String messageText = jsonRequest.get("messageText").getAsString();

        String url = "jdbc:mysql://localhost/chat_db";
        String user = "root";
        String password = "1234";

        String sql = "UPDATE messages SET message_text = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, messageText);
            ps.setInt(2, messageId);
            int result = ps.executeUpdate();

            JsonObject jsonResponse = new JsonObject();
            if (result > 0) {
                jsonResponse.addProperty("status", "success");
                jsonResponse.addProperty("message", "Message updated successfully.");
            } else {
                jsonResponse.addProperty("status", "error");
                jsonResponse.addProperty("message", "Failed to update message.");
            }
            out.print(gson.toJson(jsonResponse));
        } catch (SQLException e) {
            e.printStackTrace();
            JsonObject jsonResponse = new JsonObject();
            jsonResponse.addProperty("status", "error");
            jsonResponse.addProperty("message", e.getMessage());
            out.print(gson.toJson(jsonResponse));
        }
    }
}
