package API;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;

public class Login extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.addHeader("Access-Control-Allow-Origin", "*");
        PrintWriter out = response.getWriter();

        String usuario = request.getParameter("User");
        String password = request.getParameter("password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection db = DriverManager.getConnection("jdbc:mysql://localhost/chat_db", "root", "1234");
            Statement s = db.createStatement();
            String query = "SELECT id FROM users WHERE username='" + usuario + "' AND password='" + password + "'";
            ResultSet rs = s.executeQuery(query);

            JSONObject json = new JSONObject();
            if (rs.next()) {
                json.put("valid", true);
                json.put("userId", rs.getInt("id"));
            } else {
                json.put("valid", false);
            }

            rs.close();
            s.close();
            db.close();

            out.print(json.toString());
            out.flush();
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"valid\": false}");
            out.flush();
        }
    }
}


