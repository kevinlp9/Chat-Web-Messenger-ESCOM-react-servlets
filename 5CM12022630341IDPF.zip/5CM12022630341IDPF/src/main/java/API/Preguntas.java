package API;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import org.json.JSONArray;
import org.json.JSONObject;

public class Preguntas extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.addHeader("Access-Control-Allow-Origin", "*");
        PrintWriter out = response.getWriter();

        String userIdParam = request.getParameter("userId");
        String type = request.getParameter("type");
        int userId = Integer.parseInt(userIdParam);
        JSONArray jsonArray = new JSONArray();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection db = DriverManager.getConnection("jdbc:mysql://localhost/chat_db", "root", "1234");
            Statement s = db.createStatement();
            String query = "";

            if ("sent".equals(type)) {
                query = "SELECT DISTINCT " +
                        "m.receiver_id AS receiver_id, " +
                        "u2.username AS receiver_name " +
                        "FROM messages m " +
                        "JOIN users u2 ON m.receiver_id = u2.id " +
                        "WHERE m.sender_id = " + userId;
            } else if ("received".equals(type)) {
                query = "SELECT DISTINCT " +
                        "m.sender_id AS receiver_id, " +
                        "u1.username AS receiver_name " +
                        "FROM messages m " +
                        "JOIN users u1 ON m.sender_id = u1.id " +
                        "WHERE m.receiver_id = " + userId;
            }

            ResultSet rs = s.executeQuery(query);

            while (rs.next()) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("receiverId", rs.getInt("receiver_id"));
                jsonObject.put("receiverName", rs.getString("receiver_name"));
                jsonArray.put(jsonObject);
            }

            rs.close();
            s.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        out.print(jsonArray.toString());
        out.flush();
    }
}
