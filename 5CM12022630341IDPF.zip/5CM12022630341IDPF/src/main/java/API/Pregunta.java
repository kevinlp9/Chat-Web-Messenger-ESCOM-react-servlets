package API;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import org.json.JSONArray;
import org.json.JSONObject;

public class Pregunta extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.addHeader("Access-Control-Allow-Origin", "*");
        PrintWriter out = response.getWriter();

        String user1Id = request.getParameter("user1Id");
        String user2Id = request.getParameter("user2Id");

        JSONArray jsonArray = new JSONArray();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection db = DriverManager.getConnection("jdbc:mysql://localhost/chat_db", "root", "1234");
            Statement s = db.createStatement();
            String query = "SELECT sent_at, m.id, m.sender_id, m.receiver_id, m.message_text, " +
                           "u1.username AS sender_name, u2.username AS receiver_name " +
                           "FROM messages m " +
                           "JOIN users u1 ON m.sender_id = u1.id " +
                           "JOIN users u2 ON m.receiver_id = u2.id " +
                           "WHERE (m.sender_id = " + user1Id + " AND m.receiver_id = " + user2Id + ") " +
                           "OR (m.sender_id = " + user2Id + " AND m.receiver_id = " + user1Id + ") " +
                           "ORDER BY m.id;";
            ResultSet rs = s.executeQuery(query);

            while (rs.next()) {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("id", rs.getInt("id"));
                jsonObject.put("senderId", rs.getInt("sender_id"));
                jsonObject.put("receiverId", rs.getInt("receiver_id"));
                jsonObject.put("messageText", rs.getString("message_text"));
                jsonObject.put("senderName", rs.getString("sender_name"));
                jsonObject.put("receiverName", rs.getString("receiver_name"));
                jsonObject.put("timestamp", rs.getTimestamp("sent_at"));
                jsonArray.put(jsonObject);
            }

            rs.close();
            s.close();
            db.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        out.print(jsonArray.toString());
        out.flush();
    }
}
