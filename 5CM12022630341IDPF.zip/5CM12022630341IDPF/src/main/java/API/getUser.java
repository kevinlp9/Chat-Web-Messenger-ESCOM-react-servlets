package API;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;

public class getUser extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.addHeader("Access-Control-Allow-Origin", "*"); // Añadir cabecera CORS si es necesario
        PrintWriter out = response.getWriter();

        int userId = Integer.parseInt(request.getParameter("userId"));

        String url = "jdbc:mysql://localhost/chat_db";
        String user = "root";
        String password = "1234";

        String query = "SELECT id, username FROM users WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                JSONObject userObj = new JSONObject();
                userObj.put("id", rs.getInt("id"));
                userObj.put("username", rs.getString("username"));
                out.print(userObj.toString());
            } else {
                out.print("{}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{}");
        }
    }
}
